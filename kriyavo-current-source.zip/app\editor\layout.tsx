import type { Viewport } from "next";
import type { ReactNode } from "react";
import EditorAuthGate from "@/components/auth/EditorAuthGate";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function EditorLayout({ children }: { children: ReactNode }) {
  return <EditorAuthGate>{children}</EditorAuthGate>;
}
